#!/bin/sh
set -e
curl -fsSL -o www/three.min.js https://cdnjs.cloudflare.com/ajax/libs/three.js/r128/three.min.js
sed -i.bak 's#https://cdnjs.cloudflare.com/ajax/libs/three.js/r128/three.min.js#three.min.js#' www/index.html
rm -f www/index.html.bak
echo "three.js embutido"
